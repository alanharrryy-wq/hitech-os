# QA helpers

This subtree is intentionally reserved for future quality-package tactical helpers that should remain subordinate to the constitutional layer.
