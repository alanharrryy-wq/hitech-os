from __future__ import annotations

from typing import Any

from PySide6.QtWidgets import QApplication


def clean_text(value: Any) -> str:
    return " ".join(str(value or "").replace("\n", " ").split()).strip()


def _normalize_app_font(app: QApplication) -> None:
    try:
        font = app.font()
        point_size = int(font.pointSize())
        pixel_size = int(font.pixelSize())
        if point_size <= 0 and pixel_size <= 0:
            font.setPointSize(10)
            app.setFont(font)
    except Exception:
        pass


def ensure_app() -> QApplication:
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
        app.setQuitOnLastWindowClosed(True)
    _normalize_app_font(app)
    return app

