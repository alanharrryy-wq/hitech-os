<div align="center">

# ✨ PySide6 Glass Template Console

**Reusable PySide6 visual shell with glass styling, frameless chrome, configurable panels, and slot-based content injection.**

<p>
  <img alt="Python" src="https://img.shields.io/badge/Python-3.x-3776AB?logo=python&logoColor=white">
  <img alt="PySide6" src="https://img.shields.io/badge/PySide6-Qt_for_Python-41CD52?logo=qt&logoColor=white">
  <img alt="Platform" src="https://img.shields.io/badge/Platform-Windows%20%7C%20Desktop-0A0A0A">
  <img alt="UI" src="https://img.shields.io/badge/UI-Frameless%20Glass%20Shell-6EA8FE">
  <img alt="Status" src="https://img.shields.io/badge/Status-Template-8A63D2">
</p>

</div>

---

## 🧠 Overview

This project is a **domain-neutral desktop UI template** built with **PySide6**. It provides a polished shell for internal tools, operator consoles, dashboards, inspectors, and workflow launchers.

Instead of starting from a blank window every time, this template gives you a ready-made structure with:

- **Frameless window chrome**
- **Glass / translucent visual scene**
- **Hero header + toolbar + workspace panels + footer**
- **Config-driven actions and chips**
- **Theme switching and UI scaling**
- **Slot-based widget injection for custom content**
- **Reusable selector and progress screens**

It is best understood as a **UI foundation layer** for desktop tooling, not as a finished business application.

---

## 🚀 Why this exists

When building internal desktop tools, the boring part tends to be the shell:

- window framing
- layout scaffolding
- consistent theme behavior
- action bars
- state indicators
- placeholder surfaces for charts, tables, logs, and controls

This template solves that once, cleanly.

You keep the structure, then swap the payload.

---

## ✨ Core capabilities

### 🪟 Frameless desktop shell
The main screen is rendered as a **custom frameless dialog** with translucent background behavior and custom chrome controls.

### 🧩 Slot-based composition
The main workspace exposes configurable areas such as:

- `sidebar`
- `main`
- `aux`

Custom widgets can be injected without rewriting the shell.

### 🎛 Config-driven bootstrapping
The window behavior is configured through `TemplateConsoleConfig`, including:

- window title
- hero copy
- chips
- toolbar actions
- panel order
- sidebar / aux visibility
- footer hint
- default theme
- default UI scale

### 🎨 Theme system
The template includes a theme catalog with at least:

- `silver_frost_cyan`
- `night_ink`

### 🔎 Reusable selector screen
A dedicated selector-style dialog allows choosing workspace path, theme, and scale in a reusable entry flow.

### 📈 Progress screen
A separate progress UI exists for long-running workflows, with indeterminate / active progress states and live status messaging.

### ⚙ UI scaling
Built-in scale presets currently include:

- `90%`
- `100%`
- `110%`
- `125%`
- `150%`

### 📡 Lightweight runtime feedback
The template tracks performance-related signals in the toolbar and updates footer state based on user actions.

---

## 🏗 Architecture at a glance

```mermaid
flowchart TD
    A[starter.py] --> B[TemplateConsoleConfig]
    A --> C[TemplateConsoleWindow]
    C --> D[Window Chrome]
    C --> E[Hero Panel]
    C --> F[Toolbar Panel]
    C --> G[Workspace Panel]
    C --> H[Footer Panel]
    G --> I[Sidebar Slot]
    G --> J[Main Slot]
    G --> K[Aux Slot]
    C --> L[Theme System]
    C --> M[Scale System]
    C --> N[Glass Backdrop]
    F --> O[Selector Screen]
    F --> P[Progress Screen]
```

---

## 📂 Project structure

```text
.
├── starter.py
├── launcher_support/
│   ├── README.md
│   └── Run_Console.bat
├── visuals/
│   ├── backdrop/      # glass and scene rendering
│   ├── chrome/        # frameless behavior and title bar
│   ├── common/        # shared helpers, constants, typed config
│   ├── controls/      # buttons, chips, icons, inputs, scale selector
│   ├── effects/       # polish, hover, shadow behavior
│   ├── layout/        # scene composition
│   ├── panels/        # hero, toolbar, footer, workspace
│   ├── screens/       # template console, selector, progress
│   ├── style/         # scaling + stylesheet generation
│   ├── themes/        # theme catalog and normalization
│   └── widgets/       # primitives and placeholders
└── _dependency_graphs/
```

---

## ▶️ Getting started

### 1) Install dependencies

```bash
py -3 -m pip install PySide6
```

### 2) Run the template

From the project root:

```bash
py -3 starter.py
```

---

## 🖥 Windows quick run

If you want double-click execution, run from the project root or wire a launcher that points to:

```bash
py -3 starter.py
```

> **Note**
> The packaged `launcher_support/Run_Console.bat` currently appears to expect `starter.py` in the same directory as the `.bat`. In the provided structure, `starter.py` lives one level above, so the launcher may need a small path fix before being treated as the default entrypoint.

---

## 🧪 What the starter currently demonstrates

`starter.py` boots the shell and injects a sample widget into the `main` slot.

That demo widget shows the intended development pattern:

- keep the shell reusable
- inject project-specific widgets into workspace slots
- configure actions and labels through `TemplateConsoleConfig`
- replace placeholders with real charts, logs, tables, terminals, or inspectors

---

## 🛠 Customization model

### Adjust shell metadata
Update `TemplateConsoleConfig` in `starter.py` to change:

- title
- subtitle
- chips
- toolbar buttons
- default theme
- visible panels
- footer hint

### Inject your own widgets
Use:

```python
window.set_slot_widget("main", your_widget)
```

You can also target other slot names when available in the workspace layout.

### Add or refine themes
Theme tokens are defined in:

```text
visuals/themes/catalog.py
```

### Modify styling rules
Stylesheet generation lives in:

```text
visuals/style/stylesheet.py
```

### Expand workflows
Reusable dialogs already exist for:

- selector / workspace entry
- progress execution

This makes the template suitable for multi-step desktop tooling.

---

## 📌 Suggested use cases

This template fits especially well for:

- internal operator consoles
- command centers
- workflow launchers
- build/deploy dashboards
- QA or support tooling
- local data inspectors
- task runners with progress feedback
- multi-panel admin utilities

---

## 🧱 Design principles embedded in the codebase

- **Reusable shell, replaceable payload**
- **Visual consistency through typed config**
- **Domain-neutral composition**
- **Minimal startup wiring**
- **Clean separation between visuals, controls, and screen flows**
- **Scalable enough for internal tool families**

---

## 📉 Runtime expectations

This project expects a **graphical desktop environment**. If no display is available, startup is intentionally blocked and the program exits with a clear message.

This is a desktop-first template, not a headless CLI workflow.

---

## 🔐 Notes for maintainers

A few observations from the current package:

- There are `.bak.*` files in several modules, which look like local backup snapshots.
- `__pycache__/` is included in the package.
- `_dependency_graphs/` exists but appears empty in the current archive.
- The launcher path should likely be normalized before shipping as the recommended Windows entrypoint.

If this repo is meant to be shared broadly, cleaning those details would make the package feel more deliberate.

---

## 📍 Minimal example

```python
from PySide6.QtWidgets import QLabel
from visuals.common.types import TemplateConsoleConfig
from visuals.screens.template_console import TemplateConsoleWindow

config = TemplateConsoleConfig(
    window_title="My Console",
    hero_title="Operations Console",
    hero_subtitle="Reusable shell for internal workflows.",
    theme_id="silver_frost_cyan",
)

window = TemplateConsoleWindow(config=config)
window.set_slot_widget("main", QLabel("Hello from custom content"))
window.show()
```

---

## 🗺 Recommended next steps

If you want to evolve this from a template into a production-ready internal framework, the next sharp moves would be:

1. add a `requirements.txt` or `pyproject.toml`
2. fix and promote a single official launcher path
3. add screenshots or GIF previews
4. document slot contracts more explicitly
5. provide one or two real example integrations
6. remove backup and cache artifacts from distributable packages

---

## 📄 License

Add your project license here.

If this is an internal company template, replace this section with the appropriate ownership / usage notice.

---

<div align="center">

**Built as a reusable PySide6 glass-shell foundation for serious desktop tooling.**

</div>
